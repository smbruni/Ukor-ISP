"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import Link from "next/link"
import {
  ArrowLeft,
  Building,
  Users,
  Bell,
  Shield,
  Globe,
  Mail,
  Phone,
  Save,
  Upload,
  Download,
  Trash2,
  Eye,
} from "lucide-react"

export default function ConfiguracoesPage() {
  const [notifications, setNotifications] = useState({
    email: true,
    push: false,
    sms: false,
    weekly: true,
    monthly: true,
  })

  const [privacy, setPrivacy] = useState({
    profileVisible: true,
    dataSharing: false,
    analytics: true,
  })

  const [companyData, setCompanyData] = useState({
    name: "TechCorp Brasil",
    cnpj: "12.345.678/0001-90",
    email: "contato@techcorp.com.br",
    phone: "(11) 99999-9999",
    address: "Av. Paulista, 1000 - São Paulo, SP",
    employees: "245",
    sector: "Tecnologia",
    website: "www.techcorp.com.br",
  })

  const handleNotificationChange = (key: string, value: boolean) => {
    setNotifications((prev) => ({ ...prev, [key]: value }))
  }

  const handlePrivacyChange = (key: string, value: boolean) => {
    setPrivacy((prev) => ({ ...prev, [key]: value }))
  }

  const handleCompanyDataChange = (key: string, value: string) => {
    setCompanyData((prev) => ({ ...prev, [key]: value }))
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Link href="/">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Voltar
              </Button>
            </Link>
            <h1 className="text-xl font-semibold text-gray-900">Configurações</h1>
          </div>
          <Button>
            <Save className="w-4 h-4 mr-2" />
            Salvar Alterações
          </Button>
        </div>
      </header>

      <div className="p-6 max-w-6xl mx-auto">
        <Tabs defaultValue="empresa" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="empresa">Empresa</TabsTrigger>
            <TabsTrigger value="usuarios">Usuários</TabsTrigger>
            <TabsTrigger value="notificacoes">Notificações</TabsTrigger>
            <TabsTrigger value="privacidade">Privacidade</TabsTrigger>
            <TabsTrigger value="integracao">Integração</TabsTrigger>
          </TabsList>

          {/* Configurações da Empresa */}
          <TabsContent value="empresa" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Building className="w-5 h-5 mr-2" />
                  Informações da Empresa
                </CardTitle>
                <CardDescription>Gerencie os dados básicos da sua organização</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="company-name">Nome da Empresa</Label>
                    <Input
                      id="company-name"
                      value={companyData.name}
                      onChange={(e) => handleCompanyDataChange("name", e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="cnpj">CNPJ</Label>
                    <Input
                      id="cnpj"
                      value={companyData.cnpj}
                      onChange={(e) => handleCompanyDataChange("cnpj", e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">E-mail Corporativo</Label>
                    <Input
                      id="email"
                      type="email"
                      value={companyData.email}
                      onChange={(e) => handleCompanyDataChange("email", e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phone">Telefone</Label>
                    <Input
                      id="phone"
                      value={companyData.phone}
                      onChange={(e) => handleCompanyDataChange("phone", e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="employees">Número de Colaboradores</Label>
                    <Input
                      id="employees"
                      value={companyData.employees}
                      onChange={(e) => handleCompanyDataChange("employees", e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="sector">Setor de Atuação</Label>
                    <Select
                      value={companyData.sector}
                      onValueChange={(value) => handleCompanyDataChange("sector", value)}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Tecnologia">Tecnologia</SelectItem>
                        <SelectItem value="Saúde">Saúde</SelectItem>
                        <SelectItem value="Educação">Educação</SelectItem>
                        <SelectItem value="Financeiro">Financeiro</SelectItem>
                        <SelectItem value="Varejo">Varejo</SelectItem>
                        <SelectItem value="Indústria">Indústria</SelectItem>
                        <SelectItem value="Serviços">Serviços</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="address">Endereço</Label>
                  <Input
                    id="address"
                    value={companyData.address}
                    onChange={(e) => handleCompanyDataChange("address", e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="website">Website</Label>
                  <Input
                    id="website"
                    value={companyData.website}
                    onChange={(e) => handleCompanyDataChange("website", e.target.value)}
                  />
                </div>
              </CardContent>
            </Card>

            {/* Logo da Empresa */}
            <Card>
              <CardHeader>
                <CardTitle>Logo da Empresa</CardTitle>
                <CardDescription>Personalize a identidade visual da sua empresa na plataforma</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-6">
                  <div className="w-24 h-24 bg-blue-100 rounded-lg flex items-center justify-center">
                    <span className="text-2xl font-bold text-blue-600">TC</span>
                  </div>
                  <div className="space-y-2">
                    <Button variant="outline">
                      <Upload className="w-4 h-4 mr-2" />
                      Fazer Upload do Logo
                    </Button>
                    <p className="text-sm text-gray-600">Recomendado: 200x200px, formato PNG ou JPG</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Configurações de Avaliação */}
            <Card>
              <CardHeader>
                <CardTitle>Configurações de Avaliação ISP</CardTitle>
                <CardDescription>Defina a frequência e parâmetros das avaliações</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Frequência de Avaliação</Label>
                    <Select defaultValue="mensal">
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="semanal">Semanal</SelectItem>
                        <SelectItem value="quinzenal">Quinzenal</SelectItem>
                        <SelectItem value="mensal">Mensal</SelectItem>
                        <SelectItem value="trimestral">Trimestral</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Meta ISP Anual</Label>
                    <Input defaultValue="8.5" type="number" step="0.1" min="0" max="10" />
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch id="auto-reminder" defaultChecked />
                  <Label htmlFor="auto-reminder">Enviar lembretes automáticos para avaliação</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch id="anonymous" />
                  <Label htmlFor="anonymous">Permitir avaliações anônimas</Label>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Gestão de Usuários */}
          <TabsContent value="usuarios" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <div className="flex items-center">
                    <Users className="w-5 h-5 mr-2" />
                    Gestão de Usuários
                  </div>
                  <Button>
                    <Users className="w-4 h-4 mr-2" />
                    Convidar Usuário
                  </Button>
                </CardTitle>
                <CardDescription>Gerencie colaboradores e suas permissões na plataforma</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {/* Filtros */}
                  <div className="flex gap-4">
                    <Select defaultValue="todos">
                      <SelectTrigger className="w-40">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="todos">Todos</SelectItem>
                        <SelectItem value="admin">Administradores</SelectItem>
                        <SelectItem value="manager">Gestores</SelectItem>
                        <SelectItem value="user">Usuários</SelectItem>
                      </SelectContent>
                    </Select>
                    <Input placeholder="Buscar por nome ou e-mail..." className="flex-1" />
                  </div>

                  {/* Lista de Usuários */}
                  <div className="space-y-3">
                    {[
                      {
                        name: "Ana Silva",
                        email: "ana.silva@techcorp.com.br",
                        role: "Administrador",
                        department: "RH",
                        status: "Ativo",
                      },
                      {
                        name: "Carlos Lima",
                        email: "carlos.lima@techcorp.com.br",
                        role: "Gestor",
                        department: "TI",
                        status: "Ativo",
                      },
                      {
                        name: "Maria Santos",
                        email: "maria.santos@techcorp.com.br",
                        role: "Usuário",
                        department: "Vendas",
                        status: "Ativo",
                      },
                      {
                        name: "João Ferreira",
                        email: "joao.ferreira@techcorp.com.br",
                        role: "Usuário",
                        department: "Marketing",
                        status: "Inativo",
                      },
                    ].map((user, index) => (
                      <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                        <div className="flex items-center space-x-4">
                          <Avatar>
                            <AvatarImage src={`/placeholder.svg?height=40&width=40`} />
                            <AvatarFallback>
                              {user.name
                                .split(" ")
                                .map((n) => n[0])
                                .join("")}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <h4 className="font-medium text-gray-900">{user.name}</h4>
                            <p className="text-sm text-gray-600">{user.email}</p>
                            <div className="flex items-center space-x-2 mt-1">
                              <Badge variant="outline" className="text-xs">
                                {user.role}
                              </Badge>
                              <Badge variant="secondary" className="text-xs">
                                {user.department}
                              </Badge>
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge variant={user.status === "Ativo" ? "default" : "secondary"}>{user.status}</Badge>
                          <Button variant="outline" size="sm">
                            Editar
                          </Button>
                          <Button variant="outline" size="sm">
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Departamentos */}
            <Card>
              <CardHeader>
                <CardTitle>Departamentos</CardTitle>
                <CardDescription>Configure os departamentos da sua empresa</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex gap-2">
                    <Input placeholder="Nome do departamento" className="flex-1" />
                    <Button>Adicionar</Button>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {["Recursos Humanos", "Tecnologia", "Vendas", "Marketing", "Financeiro", "Operações"].map(
                      (dept, index) => (
                        <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                          <span className="font-medium">{dept}</span>
                          <Button variant="outline" size="sm">
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      ),
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Notificações */}
          <TabsContent value="notificacoes" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Bell className="w-5 h-5 mr-2" />
                  Configurações de Notificação
                </CardTitle>
                <CardDescription>Gerencie como e quando você recebe notificações</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <h4 className="font-medium">Canais de Notificação</h4>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <Mail className="w-4 h-4 text-gray-400" />
                        <div>
                          <Label>Notificações por E-mail</Label>
                          <p className="text-sm text-gray-600">Receba atualizações importantes por e-mail</p>
                        </div>
                      </div>
                      <Switch
                        checked={notifications.email}
                        onCheckedChange={(checked) => handleNotificationChange("email", checked)}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <Bell className="w-4 h-4 text-gray-400" />
                        <div>
                          <Label>Notificações Push</Label>
                          <p className="text-sm text-gray-600">Receba notificações no navegador</p>
                        </div>
                      </div>
                      <Switch
                        checked={notifications.push}
                        onCheckedChange={(checked) => handleNotificationChange("push", checked)}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <Phone className="w-4 h-4 text-gray-400" />
                        <div>
                          <Label>Notificações por SMS</Label>
                          <p className="text-sm text-gray-600">Receba alertas importantes por SMS</p>
                        </div>
                      </div>
                      <Switch
                        checked={notifications.sms}
                        onCheckedChange={(checked) => handleNotificationChange("sms", checked)}
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h4 className="font-medium">Frequência de Relatórios</h4>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <Label>Relatório Semanal</Label>
                        <p className="text-sm text-gray-600">Resumo semanal do ISP e atividades</p>
                      </div>
                      <Switch
                        checked={notifications.weekly}
                        onCheckedChange={(checked) => handleNotificationChange("weekly", checked)}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <Label>Relatório Mensal</Label>
                        <p className="text-sm text-gray-600">Relatório completo mensal com insights</p>
                      </div>
                      <Switch
                        checked={notifications.monthly}
                        onCheckedChange={(checked) => handleNotificationChange("monthly", checked)}
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h4 className="font-medium">Horários de Notificação</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Horário de Início</Label>
                      <Select defaultValue="08:00">
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="07:00">07:00</SelectItem>
                          <SelectItem value="08:00">08:00</SelectItem>
                          <SelectItem value="09:00">09:00</SelectItem>
                          <SelectItem value="10:00">10:00</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>Horário de Fim</Label>
                      <Select defaultValue="18:00">
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="17:00">17:00</SelectItem>
                          <SelectItem value="18:00">18:00</SelectItem>
                          <SelectItem value="19:00">19:00</SelectItem>
                          <SelectItem value="20:00">20:00</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Privacidade */}
          <TabsContent value="privacidade" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Shield className="w-5 h-5 mr-2" />
                  Configurações de Privacidade
                </CardTitle>
                <CardDescription>Controle como seus dados são utilizados e compartilhados</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <h4 className="font-medium">Visibilidade do Perfil</h4>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <Eye className="w-4 h-4 text-gray-400" />
                        <div>
                          <Label>Perfil Visível para Outros Usuários</Label>
                          <p className="text-sm text-gray-600">Outros colaboradores podem ver seu perfil básico</p>
                        </div>
                      </div>
                      <Switch
                        checked={privacy.profileVisible}
                        onCheckedChange={(checked) => handlePrivacyChange("profileVisible", checked)}
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h4 className="font-medium">Compartilhamento de Dados</h4>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <Label>Compartilhar Dados Anonimizados</Label>
                        <p className="text-sm text-gray-600">Permitir uso de dados anonimizados para pesquisas</p>
                      </div>
                      <Switch
                        checked={privacy.dataSharing}
                        onCheckedChange={(checked) => handlePrivacyChange("dataSharing", checked)}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <Label>Analytics e Melhorias</Label>
                        <p className="text-sm text-gray-600">Ajudar a melhorar a plataforma com dados de uso</p>
                      </div>
                      <Switch
                        checked={privacy.analytics}
                        onCheckedChange={(checked) => handlePrivacyChange("analytics", checked)}
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h4 className="font-medium">Controle de Dados</h4>
                  <div className="space-y-3">
                    <Button variant="outline" className="w-full justify-start">
                      <Download className="w-4 h-4 mr-2" />
                      Exportar Meus Dados
                    </Button>
                    <Button variant="outline" className="w-full justify-start text-red-600 hover:text-red-700">
                      <Trash2 className="w-4 h-4 mr-2" />
                      Solicitar Exclusão de Dados
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Segurança */}
            <Card>
              <CardHeader>
                <CardTitle>Segurança da Conta</CardTitle>
                <CardDescription>Gerencie a segurança da sua conta</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <Button variant="outline" className="w-full justify-start">
                    <Shield className="w-4 h-4 mr-2" />
                    Alterar Senha
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <Phone className="w-4 h-4 mr-2" />
                    Configurar Autenticação em Duas Etapas
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <Eye className="w-4 h-4 mr-2" />
                    Ver Sessões Ativas
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Integração */}
          <TabsContent value="integracao" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Globe className="w-5 h-5 mr-2" />
                  Integrações
                </CardTitle>
                <CardDescription>Conecte a Ukor com outras ferramentas da sua empresa</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {[
                    {
                      name: "Microsoft Teams",
                      description: "Sincronize com calendário e reuniões",
                      connected: true,
                      logo: "MT",
                    },
                    { name: "Slack", description: "Receba notificações no Slack", connected: false, logo: "SL" },
                    {
                      name: "Google Workspace",
                      description: "Integração com Gmail e Calendar",
                      connected: true,
                      logo: "GW",
                    },
                    { name: "Zoom", description: "Agende workshops e reuniões", connected: false, logo: "ZM" },
                    { name: "SAP SuccessFactors", description: "Sincronize dados de RH", connected: false, logo: "SF" },
                    { name: "Workday", description: "Integração com sistema de RH", connected: false, logo: "WD" },
                  ].map((integration, index) => (
                    <div key={index} className="p-4 border rounded-lg">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center space-x-3">
                          <div className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center">
                            <span className="text-xs font-bold text-gray-600">{integration.logo}</span>
                          </div>
                          <div>
                            <h4 className="font-medium">{integration.name}</h4>
                            <p className="text-sm text-gray-600">{integration.description}</p>
                          </div>
                        </div>
                        <Badge variant={integration.connected ? "default" : "outline"}>
                          {integration.connected ? "Conectado" : "Disponível"}
                        </Badge>
                      </div>
                      <Button variant={integration.connected ? "outline" : "default"} size="sm" className="w-full">
                        {integration.connected ? "Configurar" : "Conectar"}
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* API e Webhooks */}
            <Card>
              <CardHeader>
                <CardTitle>API e Webhooks</CardTitle>
                <CardDescription>Configure integrações personalizadas</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                      <h4 className="font-medium">Chave da API</h4>
                      <p className="text-sm text-gray-600">Use para integrações personalizadas</p>
                    </div>
                    <Button variant="outline" size="sm">
                      Gerar Nova Chave
                    </Button>
                  </div>
                  <div className="space-y-2">
                    <Label>URL do Webhook</Label>
                    <Input placeholder="https://sua-empresa.com/webhook" />
                    <p className="text-sm text-gray-600">Receba notificações em tempo real sobre mudanças no ISP</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
