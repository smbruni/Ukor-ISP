"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Download, TrendingUp, Users, Building, FileText, BarChart3, PieChart, ArrowLeft } from "lucide-react"
import Link from "next/link"

export default function RelatoriosPage() {
  const reportData = {
    periodo: "Maio 2024",
    ispGeral: 7.2,
    evolucao: 0.3,
    participacao: 87,
    totalColaboradores: 245,
    departamentos: [
      { nome: "RH", isp: 8.1, participacao: 100 },
      { nome: "TI", isp: 6.9, participacao: 84 },
      { nome: "Vendas", isp: 7.5, participacao: 91 },
      { nome: "Marketing", isp: 7.8, participacao: 96 },
    ],
    pilares: [
      { nome: "Saúde Mental", score: 6.8, status: "Atenção" },
      { nome: "Saúde Física", score: 7.5, status: "Bom" },
      { nome: "Nutrição", score: 7.0, status: "Bom" },
      { nome: "Sono", score: 6.9, status: "Bom" },
      { nome: "Produtividade", score: 7.8, status: "Muito Bom" },
      { nome: "Gestão de Estresse", score: 6.5, status: "Atenção" },
    ],
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Link href="/">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Voltar
              </Button>
            </Link>
            <h1 className="text-xl font-semibold text-gray-900">Relatórios de Saúde e Performance</h1>
          </div>
          <div className="flex items-center space-x-2">
            <Select defaultValue="maio2024">
              <SelectTrigger className="w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="maio2024">Maio 2024</SelectItem>
                <SelectItem value="abril2024">Abril 2024</SelectItem>
                <SelectItem value="marco2024">Março 2024</SelectItem>
              </SelectContent>
            </Select>
            <Button>
              <Download className="w-4 h-4 mr-2" />
              Exportar PDF
            </Button>
          </div>
        </div>
      </header>

      <div className="p-6 max-w-7xl mx-auto">
        {/* Resumo Executivo */}
        <Card className="mb-6 bg-gradient-to-r from-blue-50 to-purple-50">
          <CardHeader>
            <CardTitle className="flex items-center">
              <FileText className="w-5 h-5 mr-2" />
              Resumo Executivo - {reportData.periodo}
            </CardTitle>
            <CardDescription>Visão geral do Índice de Saúde e Performance da TechCorp Brasil</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-600 mb-2">{reportData.ispGeral}</div>
                <div className="text-sm text-gray-600">ISP Geral</div>
                <Badge variant="secondary" className="mt-1 bg-green-100 text-green-800">
                  +{reportData.evolucao} vs mês anterior
                </Badge>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-green-600 mb-2">{reportData.participacao}%</div>
                <div className="text-sm text-gray-600">Participação</div>
                <div className="text-xs text-gray-500 mt-1">
                  {Math.round((reportData.participacao / 100) * reportData.totalColaboradores)}/
                  {reportData.totalColaboradores} colaboradores
                </div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-purple-600 mb-2">6.8</div>
                <div className="text-sm text-gray-600">Menor Score</div>
                <div className="text-xs text-gray-500 mt-1">Saúde Mental</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-orange-600 mb-2">7.8</div>
                <div className="text-sm text-gray-600">Maior Score</div>
                <div className="text-xs text-gray-500 mt-1">Produtividade</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Tabs defaultValue="departamentos" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="departamentos">Departamentos</TabsTrigger>
            <TabsTrigger value="pilares">Pilares de Saúde</TabsTrigger>
            <TabsTrigger value="demografico">Demográfico</TabsTrigger>
            <TabsTrigger value="acoes">Plano de Ação</TabsTrigger>
          </TabsList>

          <TabsContent value="departamentos" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Building className="w-5 h-5 mr-2" />
                  Análise por Departamento
                </CardTitle>
                <CardDescription>Performance detalhada de cada área da empresa</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {reportData.departamentos.map((dept, index) => (
                    <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div className="flex items-center space-x-4">
                        <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                          <span className="font-bold text-blue-600">{dept.isp}</span>
                        </div>
                        <div>
                          <h3 className="font-medium text-gray-900">{dept.nome}</h3>
                          <p className="text-sm text-gray-600">Participação: {dept.participacao}%</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <Badge variant={dept.isp >= 8 ? "default" : dept.isp >= 6 ? "secondary" : "destructive"}>
                          {dept.isp >= 8 ? "Excelente" : dept.isp >= 6 ? "Bom" : "Atenção"}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="pilares" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <BarChart3 className="w-5 h-5 mr-2" />
                  Análise dos Pilares de Saúde
                </CardTitle>
                <CardDescription>Detalhamento de cada pilar avaliado</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {reportData.pilares.map((pilar, index) => (
                    <div key={index} className="p-4 border rounded-lg">
                      <div className="flex items-center justify-between mb-3">
                        <h3 className="font-medium text-gray-900">{pilar.nome}</h3>
                        <Badge
                          variant={
                            pilar.status === "Muito Bom"
                              ? "default"
                              : pilar.status === "Bom"
                                ? "secondary"
                                : "destructive"
                          }
                        >
                          {pilar.status}
                        </Badge>
                      </div>
                      <div className="flex items-center space-x-3">
                        <div className="text-2xl font-bold text-blue-600">{pilar.score}</div>
                        <div className="flex-1 bg-gray-200 rounded-full h-2">
                          <div className="bg-blue-600 h-2 rounded-full" style={{ width: `${pilar.score * 10}%` }}></div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="demografico" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <PieChart className="w-5 h-5 mr-2" />
                    Distribuição por Faixa Etária
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">18-25 anos</span>
                      <div className="flex items-center space-x-2">
                        <div className="w-20 bg-gray-200 rounded-full h-2">
                          <div className="bg-blue-600 h-2 rounded-full" style={{ width: "15%" }}></div>
                        </div>
                        <span className="text-sm font-medium">15%</span>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">26-35 anos</span>
                      <div className="flex items-center space-x-2">
                        <div className="w-20 bg-gray-200 rounded-full h-2">
                          <div className="bg-blue-600 h-2 rounded-full" style={{ width: "45%" }}></div>
                        </div>
                        <span className="text-sm font-medium">45%</span>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">36-45 anos</span>
                      <div className="flex items-center space-x-2">
                        <div className="w-20 bg-gray-200 rounded-full h-2">
                          <div className="bg-blue-600 h-2 rounded-full" style={{ width: "30%" }}></div>
                        </div>
                        <span className="text-sm font-medium">30%</span>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">46+ anos</span>
                      <div className="flex items-center space-x-2">
                        <div className="w-20 bg-gray-200 rounded-full h-2">
                          <div className="bg-blue-600 h-2 rounded-full" style={{ width: "10%" }}></div>
                        </div>
                        <span className="text-sm font-medium">10%</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Users className="w-5 h-5 mr-2" />
                    Distribuição por Gênero
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="text-center">
                      <div className="text-3xl font-bold text-blue-600 mb-2">52%</div>
                      <div className="text-sm text-gray-600">Feminino</div>
                      <div className="text-xs text-gray-500">127 colaboradoras</div>
                    </div>
                    <div className="text-center">
                      <div className="text-3xl font-bold text-purple-600 mb-2">48%</div>
                      <div className="text-sm text-gray-600">Masculino</div>
                      <div className="text-xs text-gray-500">118 colaboradores</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="acoes" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <TrendingUp className="w-5 h-5 mr-2" />
                  Plano de Ação Recomendado
                </CardTitle>
                <CardDescription>Ações prioritárias baseadas na análise do ISP</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="p-4 bg-red-50 border-l-4 border-red-400 rounded-lg">
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="font-semibold text-red-900 mb-2">🚨 Ação Urgente</h3>
                        <h4 className="font-medium text-red-800">Workshop de Gestão de Estresse</h4>
                        <p className="text-sm text-red-700 mt-1">
                          Score baixo detectado (6.5). Implementar programa de mindfulness e técnicas de relaxamento.
                        </p>
                        <div className="mt-3 flex items-center space-x-4 text-sm text-red-600">
                          <span>📅 Prazo: 7 dias</span>
                          <span>👥 Público: Todos os departamentos</span>
                          <span>💰 Investimento: R$ 15.000</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="p-4 bg-yellow-50 border-l-4 border-yellow-400 rounded-lg">
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="font-semibold text-yellow-900 mb-2">⚠️ Ação Importante</h3>
                        <h4 className="font-medium text-yellow-800">Programa de Saúde Mental</h4>
                        <p className="text-sm text-yellow-700 mt-1">
                          Implementar sessões de terapia em grupo e palestras sobre bem-estar mental.
                        </p>
                        <div className="mt-3 flex items-center space-x-4 text-sm text-yellow-600">
                          <span>📅 Prazo: 30 dias</span>
                          <span>👥 Público: Foco no departamento de TI</span>
                          <span>💰 Investimento: R$ 25.000</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="p-4 bg-blue-50 border-l-4 border-blue-400 rounded-lg">
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="font-semibold text-blue-900 mb-2">📋 Ação Planejada</h3>
                        <h4 className="font-medium text-blue-800">Programa de Exercícios Corporativos</h4>
                        <p className="text-sm text-blue-700 mt-1">
                          Parcerias com academias e implementação de ginástica laboral.
                        </p>
                        <div className="mt-3 flex items-center space-x-4 text-sm text-blue-600">
                          <span>📅 Prazo: 60 dias</span>
                          <span>👥 Público: Todos os colaboradores</span>
                          <span>💰 Investimento: R$ 40.000</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="mt-6 p-4 bg-gray-50 rounded-lg">
                    <h3 className="font-semibold text-gray-900 mb-3">📊 Resumo do Investimento</h3>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-gray-900">R$ 80.000</div>
                        <div className="text-sm text-gray-600">Investimento Total</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-green-600">8.5</div>
                        <div className="text-sm text-gray-600">Meta ISP (6 meses)</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-blue-600">ROI 3:1</div>
                        <div className="text-sm text-gray-600">Retorno Esperado</div>
                      </div>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Link href="/plano-acao">
                      <Button>Ver Plano Completo</Button>
                    </Link>
                    <Button variant="outline">Exportar Plano</Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
