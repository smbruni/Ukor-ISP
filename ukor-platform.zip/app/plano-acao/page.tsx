"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Checkbox } from "@/components/ui/checkbox"
import Link from "next/link"
import {
  ArrowLeft,
  Target,
  Calendar,
  Clock,
  Users,
  TrendingUp,
  AlertTriangle,
  CheckCircle,
  Play,
  BookOpen,
  DollarSign,
} from "lucide-react"

export default function PlanoAcaoPage() {
  const [completedActions, setCompletedActions] = useState<string[]>([])

  const toggleAction = (actionId: string) => {
    setCompletedActions((prev) =>
      prev.includes(actionId) ? prev.filter((id) => id !== actionId) : [...prev, actionId],
    )
  }

  const urgentActions = [
    {
      id: "urgent_1",
      title: "Workshop de Gestão de Estresse",
      description: "Implementar programa de mindfulness e técnicas de relaxamento para reduzir o estresse da equipe",
      priority: "Urgente",
      deadline: "7 dias",
      department: "Todos os departamentos",
      investment: "R$ 15.000",
      expectedImpact: "+0.8 no ISP de Estresse",
      status: "pending",
      tasks: [
        "Contratar facilitador especializado",
        "Agendar sessões para todos os departamentos",
        "Preparar material de apoio",
        "Definir métricas de acompanhamento",
      ],
      relatedTrainings: ["Mindfulness para Redução do Estresse", "Respiração Consciente Anti-Estresse"],
    },
  ]

  const importantActions = [
    {
      id: "important_1",
      title: "Programa de Saúde Mental",
      description: "Implementar sessões de terapia em grupo e palestras sobre bem-estar mental",
      priority: "Importante",
      deadline: "30 dias",
      department: "Foco no departamento de TI",
      investment: "R$ 25.000",
      expectedImpact: "+0.6 no ISP de Saúde Mental",
      status: "in_progress",
      progress: 25,
      tasks: [
        "Contratar psicólogos especializados",
        "Criar cronograma de sessões",
        "Desenvolver material educativo",
        "Implementar sistema de feedback",
      ],
      relatedTrainings: ["Mindfulness para Redução do Estresse"],
    },
    {
      id: "important_2",
      title: "Programa de Nutrição Corporativa",
      description: "Melhorar a alimentação no ambiente de trabalho com cardápios balanceados",
      priority: "Importante",
      deadline: "45 dias",
      department: "Todos os departamentos",
      investment: "R$ 20.000",
      expectedImpact: "+0.5 no ISP de Nutrição",
      status: "pending",
      tasks: [
        "Contratar nutricionista",
        "Revisar cardápio do refeitório",
        "Implementar lanches saudáveis",
        "Criar programa educativo",
      ],
      relatedTrainings: ["Nutrição Funcional no Trabalho"],
    },
  ]

  const plannedActions = [
    {
      id: "planned_1",
      title: "Programa de Exercícios Corporativos",
      description: "Parcerias com academias e implementação de ginástica laboral",
      priority: "Planejada",
      deadline: "60 dias",
      department: "Todos os colaboradores",
      investment: "R$ 40.000",
      expectedImpact: "+0.7 no ISP de Saúde Física",
      status: "pending",
      tasks: [
        "Negociar parcerias com academias",
        "Contratar personal trainer",
        "Criar cronograma de atividades",
        "Instalar equipamentos básicos",
      ],
      relatedTrainings: ["Exercícios de Escritório"],
    },
    {
      id: "planned_2",
      title: "Programa de Higiene do Sono",
      description: "Educação sobre qualidade do sono e implementação de políticas de descanso",
      priority: "Planejada",
      deadline: "90 dias",
      department: "Todos os colaboradores",
      investment: "R$ 10.000",
      expectedImpact: "+0.4 no ISP de Sono",
      status: "pending",
      tasks: [
        "Desenvolver material educativo",
        "Implementar política de horários flexíveis",
        "Criar espaço de descanso",
        "Monitorar resultados",
      ],
      relatedTrainings: ["Higiene do Sono para Profissionais"],
    },
  ]

  const allActions = [...urgentActions, ...importantActions, ...plannedActions]
  const totalInvestment = allActions.reduce(
    (sum, action) => sum + Number.parseInt(action.investment.replace(/[^\d]/g, "")),
    0,
  )

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "Urgente":
        return "bg-red-100 text-red-800 border-red-200"
      case "Importante":
        return "bg-yellow-100 text-yellow-800 border-yellow-200"
      case "Planejada":
        return "bg-blue-100 text-blue-800 border-blue-200"
      default:
        return "bg-gray-100 text-gray-800 border-gray-200"
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return <CheckCircle className="w-5 h-5 text-green-600" />
      case "in_progress":
        return <Play className="w-5 h-5 text-blue-600" />
      default:
        return <Clock className="w-5 h-5 text-gray-400" />
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Link href="/">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Voltar
              </Button>
            </Link>
            <h1 className="text-xl font-semibold text-gray-900">Plano de Ação Personalizado</h1>
          </div>
          <Badge variant="outline" className="bg-green-50 text-green-700">
            Meta ISP: 8.5 em 6 meses
          </Badge>
        </div>
      </header>

      <div className="p-6 max-w-7xl mx-auto">
        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="p-4 text-center">
              <Target className="w-8 h-8 text-blue-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-gray-900">{allActions.length}</div>
              <div className="text-sm text-gray-600">Ações Totais</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <AlertTriangle className="w-8 h-8 text-red-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-red-600">{urgentActions.length}</div>
              <div className="text-sm text-gray-600">Ações Urgentes</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <DollarSign className="w-8 h-8 text-green-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-gray-900">R$ {totalInvestment.toLocaleString()}</div>
              <div className="text-sm text-gray-600">Investimento Total</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <TrendingUp className="w-8 h-8 text-purple-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-purple-600">+1.8</div>
              <div className="text-sm text-gray-600">Impacto Esperado ISP</div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="urgentes" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="urgentes">Ações Urgentes</TabsTrigger>
            <TabsTrigger value="importantes">Importantes</TabsTrigger>
            <TabsTrigger value="planejadas">Planejadas</TabsTrigger>
            <TabsTrigger value="cronograma">Cronograma</TabsTrigger>
          </TabsList>

          <TabsContent value="urgentes" className="space-y-4">
            {urgentActions.map((action) => (
              <Card key={action.id} className="border-l-4 border-red-400">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex items-start space-x-3">
                      {getStatusIcon(action.status)}
                      <div>
                        <CardTitle className="text-lg">{action.title}</CardTitle>
                        <CardDescription className="mt-1">{action.description}</CardDescription>
                      </div>
                    </div>
                    <Badge className={getPriorityColor(action.priority)}>{action.priority}</Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-sm">
                    <div className="flex items-center space-x-2">
                      <Calendar className="w-4 h-4 text-gray-400" />
                      <span>
                        <strong>Prazo:</strong> {action.deadline}
                      </span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Users className="w-4 h-4 text-gray-400" />
                      <span>
                        <strong>Público:</strong> {action.department}
                      </span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <DollarSign className="w-4 h-4 text-gray-400" />
                      <span>
                        <strong>Investimento:</strong> {action.investment}
                      </span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <TrendingUp className="w-4 h-4 text-gray-400" />
                      <span>
                        <strong>Impacto:</strong> {action.expectedImpact}
                      </span>
                    </div>
                  </div>

                  <div>
                    <h4 className="font-medium mb-2">Tarefas:</h4>
                    <div className="space-y-2">
                      {action.tasks.map((task, index) => (
                        <div key={index} className="flex items-center space-x-2">
                          <Checkbox
                            id={`task-${action.id}-${index}`}
                            checked={completedActions.includes(`${action.id}-${index}`)}
                            onCheckedChange={() => toggleAction(`${action.id}-${index}`)}
                          />
                          <label htmlFor={`task-${action.id}-${index}`} className="text-sm cursor-pointer">
                            {task}
                          </label>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h4 className="font-medium mb-2">Treinamentos Relacionados:</h4>
                    <div className="flex gap-2">
                      {action.relatedTrainings.map((training, index) => (
                        <Link key={index} href="/treinamentos">
                          <Badge variant="outline" className="cursor-pointer hover:bg-gray-100">
                            <BookOpen className="w-3 h-3 mr-1" />
                            {training}
                          </Badge>
                        </Link>
                      ))}
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Button className="bg-red-600 hover:bg-red-700">Iniciar Ação</Button>
                    <Button variant="outline">Ver Detalhes</Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </TabsContent>

          <TabsContent value="importantes" className="space-y-4">
            {importantActions.map((action) => (
              <Card key={action.id} className="border-l-4 border-yellow-400">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex items-start space-x-3">
                      {getStatusIcon(action.status)}
                      <div>
                        <CardTitle className="text-lg">{action.title}</CardTitle>
                        <CardDescription className="mt-1">{action.description}</CardDescription>
                      </div>
                    </div>
                    <Badge className={getPriorityColor(action.priority)}>{action.priority}</Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  {action.progress && (
                    <div>
                      <div className="flex justify-between text-sm text-gray-600 mb-1">
                        <span>Progresso</span>
                        <span>{action.progress}%</span>
                      </div>
                      <Progress value={action.progress} className="h-2" />
                    </div>
                  )}

                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-sm">
                    <div className="flex items-center space-x-2">
                      <Calendar className="w-4 h-4 text-gray-400" />
                      <span>
                        <strong>Prazo:</strong> {action.deadline}
                      </span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Users className="w-4 h-4 text-gray-400" />
                      <span>
                        <strong>Público:</strong> {action.department}
                      </span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <DollarSign className="w-4 h-4 text-gray-400" />
                      <span>
                        <strong>Investimento:</strong> {action.investment}
                      </span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <TrendingUp className="w-4 h-4 text-gray-400" />
                      <span>
                        <strong>Impacto:</strong> {action.expectedImpact}
                      </span>
                    </div>
                  </div>

                  <div>
                    <h4 className="font-medium mb-2">Tarefas:</h4>
                    <div className="space-y-2">
                      {action.tasks.map((task, index) => (
                        <div key={index} className="flex items-center space-x-2">
                          <Checkbox
                            id={`task-${action.id}-${index}`}
                            checked={completedActions.includes(`${action.id}-${index}`)}
                            onCheckedChange={() => toggleAction(`${action.id}-${index}`)}
                          />
                          <label htmlFor={`task-${action.id}-${index}`} className="text-sm cursor-pointer">
                            {task}
                          </label>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h4 className="font-medium mb-2">Treinamentos Relacionados:</h4>
                    <div className="flex gap-2">
                      {action.relatedTrainings?.map((training, index) => (
                        <Link key={index} href="/treinamentos">
                          <Badge variant="outline" className="cursor-pointer hover:bg-gray-100">
                            <BookOpen className="w-3 h-3 mr-1" />
                            {training}
                          </Badge>
                        </Link>
                      ))}
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Button className="bg-yellow-600 hover:bg-yellow-700">
                      {action.status === "in_progress" ? "Continuar" : "Iniciar Ação"}
                    </Button>
                    <Button variant="outline">Ver Detalhes</Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </TabsContent>

          <TabsContent value="planejadas" className="space-y-4">
            {plannedActions.map((action) => (
              <Card key={action.id} className="border-l-4 border-blue-400">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex items-start space-x-3">
                      {getStatusIcon(action.status)}
                      <div>
                        <CardTitle className="text-lg">{action.title}</CardTitle>
                        <CardDescription className="mt-1">{action.description}</CardDescription>
                      </div>
                    </div>
                    <Badge className={getPriorityColor(action.priority)}>{action.priority}</Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-sm">
                    <div className="flex items-center space-x-2">
                      <Calendar className="w-4 h-4 text-gray-400" />
                      <span>
                        <strong>Prazo:</strong> {action.deadline}
                      </span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Users className="w-4 h-4 text-gray-400" />
                      <span>
                        <strong>Público:</strong> {action.department}
                      </span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <DollarSign className="w-4 h-4 text-gray-400" />
                      <span>
                        <strong>Investimento:</strong> {action.investment}
                      </span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <TrendingUp className="w-4 h-4 text-gray-400" />
                      <span>
                        <strong>Impacto:</strong> {action.expectedImpact}
                      </span>
                    </div>
                  </div>

                  <div>
                    <h4 className="font-medium mb-2">Tarefas:</h4>
                    <div className="space-y-2">
                      {action.tasks.map((task, index) => (
                        <div key={index} className="flex items-center space-x-2">
                          <Checkbox
                            id={`task-${action.id}-${index}`}
                            checked={completedActions.includes(`${action.id}-${index}`)}
                            onCheckedChange={() => toggleAction(`${action.id}-${index}`)}
                          />
                          <label htmlFor={`task-${action.id}-${index}`} className="text-sm cursor-pointer">
                            {task}
                          </label>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h4 className="font-medium mb-2">Treinamentos Relacionados:</h4>
                    <div className="flex gap-2">
                      {action.relatedTrainings?.map((training, index) => (
                        <Link key={index} href="/treinamentos">
                          <Badge variant="outline" className="cursor-pointer hover:bg-gray-100">
                            <BookOpen className="w-3 h-3 mr-1" />
                            {training}
                          </Badge>
                        </Link>
                      ))}
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Button variant="outline">Agendar para Mais Tarde</Button>
                    <Button variant="outline">Ver Detalhes</Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </TabsContent>

          <TabsContent value="cronograma" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Cronograma de Implementação</CardTitle>
                <CardDescription>Visualização temporal das ações planejadas</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="relative">
                    <div className="absolute left-4 top-0 bottom-0 w-0.5 bg-gray-200"></div>

                    {/* Próximos 7 dias */}
                    <div className="relative flex items-start space-x-4 pb-6">
                      <div className="w-8 h-8 bg-red-500 rounded-full flex items-center justify-center text-white text-sm font-bold">
                        7d
                      </div>
                      <div className="flex-1">
                        <h3 className="font-semibold text-red-900">Próximos 7 dias</h3>
                        <div className="mt-2 space-y-2">
                          {urgentActions.map((action) => (
                            <div key={action.id} className="p-3 bg-red-50 rounded-lg border-l-4 border-red-400">
                              <h4 className="font-medium">{action.title}</h4>
                              <p className="text-sm text-gray-600">
                                {action.investment} • {action.department}
                              </p>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>

                    {/* Próximos 30 dias */}
                    <div className="relative flex items-start space-x-4 pb-6">
                      <div className="w-8 h-8 bg-yellow-500 rounded-full flex items-center justify-center text-white text-sm font-bold">
                        30d
                      </div>
                      <div className="flex-1">
                        <h3 className="font-semibold text-yellow-900">Próximos 30 dias</h3>
                        <div className="mt-2 space-y-2">
                          {importantActions
                            .filter((a) => a.deadline.includes("30"))
                            .map((action) => (
                              <div key={action.id} className="p-3 bg-yellow-50 rounded-lg border-l-4 border-yellow-400">
                                <h4 className="font-medium">{action.title}</h4>
                                <p className="text-sm text-gray-600">
                                  {action.investment} • {action.department}
                                </p>
                              </div>
                            ))}
                        </div>
                      </div>
                    </div>

                    {/* Próximos 60-90 dias */}
                    <div className="relative flex items-start space-x-4">
                      <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white text-sm font-bold">
                        90d
                      </div>
                      <div className="flex-1">
                        <h3 className="font-semibold text-blue-900">Próximos 60-90 dias</h3>
                        <div className="mt-2 space-y-2">
                          {plannedActions.map((action) => (
                            <div key={action.id} className="p-3 bg-blue-50 rounded-lg border-l-4 border-blue-400">
                              <h4 className="font-medium">{action.title}</h4>
                              <p className="text-sm text-gray-600">
                                {action.investment} • {action.department}
                              </p>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* ROI Projection */}
            <Card>
              <CardHeader>
                <CardTitle>Projeção de Retorno do Investimento</CardTitle>
                <CardDescription>Estimativa de melhoria do ISP ao longo do tempo</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="text-center p-4 bg-green-50 rounded-lg">
                    <div className="text-3xl font-bold text-green-600">R$ {totalInvestment.toLocaleString()}</div>
                    <div className="text-sm text-gray-600">Investimento Total</div>
                  </div>
                  <div className="text-center p-4 bg-blue-50 rounded-lg">
                    <div className="text-3xl font-bold text-blue-600">8.5</div>
                    <div className="text-sm text-gray-600">ISP Meta (6 meses)</div>
                  </div>
                  <div className="text-center p-4 bg-purple-50 rounded-lg">
                    <div className="text-3xl font-bold text-purple-600">ROI 3:1</div>
                    <div className="text-sm text-gray-600">Retorno Esperado</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
