"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import Link from "next/link"
import {
  Brain,
  Heart,
  Apple,
  Moon,
  TrendingUp,
  Shield,
  Calendar,
  ArrowUp,
  Target,
  BookOpen,
  Play,
  Clock,
  CheckCircle,
  Settings,
} from "lucide-react"

import { ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, Legend } from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"

export default function Dashboard() {
  const ispScore = 7.2
  const ispTrend = 0.3

  const healthPillars = [
    { name: "Saúde Mental", score: 6.8, trend: 0.5, icon: Brain, color: "bg-purple-500" },
    { name: "Saúde Física", score: 7.5, trend: -0.2, icon: Heart, color: "bg-red-500" },
    { name: "Nutrição", score: 7.0, trend: 0.3, icon: Apple, color: "bg-green-500" },
    { name: "Sono", score: 6.9, trend: 0.1, icon: Moon, color: "bg-blue-500" },
    { name: "Produtividade", score: 7.8, trend: 0.4, icon: TrendingUp, color: "bg-orange-500" },
    { name: "Gestão de Estresse", score: 6.5, trend: -0.1, icon: Shield, color: "bg-indigo-500" },
  ]

  const recentTrainings = [
    { title: "Mindfulness no Trabalho", duration: "45 min", completed: true, type: "Vídeo" },
    { title: "Nutrição Funcional", duration: "30 min", completed: false, type: "Curso" },
    { title: "Gestão do Tempo", duration: "60 min", completed: false, type: "Workshop" },
  ]

  const getScoreColor = (score: number) => {
    if (score >= 8) return "text-purple-600"
    if (score >= 6) return "text-green-600"
    if (score >= 4) return "text-yellow-600"
    return "text-red-600"
  }

  const getScoreBg = (score: number) => {
    if (score >= 8) return "bg-purple-100"
    if (score >= 6) return "bg-green-100"
    if (score >= 4) return "bg-yellow-100"
    return "bg-red-100"
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-sm">U</span>
            </div>
            <h1 className="text-xl font-semibold text-gray-900">Ukor</h1>
          </div>
          <div className="flex items-center space-x-4">
            <Link href="/relatorios">
              <Button variant="outline" size="sm">
                <Calendar className="w-4 h-4 mr-2" />
                Relatório Mensal
              </Button>
            </Link>
            <Link href="/configuracoes">
              <Button variant="outline" size="sm">
                <Settings className="w-4 h-4 mr-2" />
                Configurações
              </Button>
            </Link>
            <Avatar>
              <AvatarImage src="/placeholder.svg?height=32&width=32" />
              <AvatarFallback>AD</AvatarFallback>
            </Avatar>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="bg-white border-b border-gray-200 px-6 py-3">
        <div className="flex space-x-8">
          <Button variant="ghost" className="text-blue-600 border-b-2 border-blue-600">
            Visão Geral
          </Button>
          <Link href="/isp">
            <Button variant="ghost" className="text-gray-600">
              Meu ISP
            </Button>
          </Link>
          <Link href="/plano-acao">
            <Button variant="ghost" className="text-gray-600">
              Plano de Ação
            </Button>
          </Link>
          <Link href="/treinamentos">
            <Button variant="ghost" className="text-gray-600">
              Treinamentos
            </Button>
          </Link>
          <Link href="/relatorios">
            <Button variant="ghost" className="text-gray-600">
              Relatórios
            </Button>
          </Link>
        </div>
      </nav>

      <div className="p-6 max-w-7xl mx-auto">
        {/* Company Header */}
        <div className="mb-6">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">TechCorp Brasil</h2>
          <p className="text-gray-600">245 colaboradores • Tecnologia • São Paulo, SP</p>
        </div>

        {/* ISP Score Card - Simples e Claro */}
        <Card className="mb-6 bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-lg text-gray-900">Seu ISP Atual</CardTitle>
                <CardDescription>Índice de Saúde e Performance</CardDescription>
              </div>
              <Badge variant="secondary" className="bg-green-100 text-green-800">
                <ArrowUp className="w-3 h-3 mr-1" />+{ispTrend} este mês
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-6">
                <div className={`w-20 h-20 rounded-full flex items-center justify-center ${getScoreBg(ispScore)}`}>
                  <span className={`text-2xl font-bold ${getScoreColor(ispScore)}`}>{ispScore}</span>
                </div>
                <div>
                  <div className="text-sm text-gray-600 mb-1">Classificação</div>
                  <div className="text-lg font-semibold text-gray-900">Bom</div>
                  <div className="text-sm text-gray-500">Continue investindo em saúde!</div>
                </div>
              </div>
              <Link href="/isp">
                <Button>Nova Avaliação</Button>
              </Link>
            </div>
          </CardContent>
        </Card>

        {/* Gráfico de Radar - Seção Separada e Clara */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-lg text-gray-900">Detalhamento por Pilares</CardTitle>
            <CardDescription>Visualização do seu desempenho em cada área de saúde</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Gráfico de Radar */}
              <div className="lg:col-span-2">
                <div className="h-80 w-full">
                  <ChartContainer
                    config={{
                      atual: {
                        label: "Sua Pontuação",
                        color: "hsl(220, 70%, 50%)",
                      },
                      meta: {
                        label: "Meta da Empresa",
                        color: "hsl(120, 40%, 60%)",
                      },
                    }}
                  >
                    <ResponsiveContainer width="100%" height="100%">
                      <RadarChart
                        data={[
                          { pilar: "Saúde Mental", atual: 6.8, meta: 8.5 },
                          { pilar: "Saúde Física", atual: 7.5, meta: 8.5 },
                          { pilar: "Sono", atual: 6.9, meta: 8.5 },
                          { pilar: "Nutrição", atual: 7.0, meta: 8.5 },
                          { pilar: "Estresse", atual: 6.5, meta: 8.5 },
                          { pilar: "Produtividade", atual: 7.8, meta: 8.5 },
                        ]}
                        margin={{ top: 20, right: 20, bottom: 20, left: 20 }}
                      >
                        <PolarGrid stroke="#e2e8f0" />
                        <PolarAngleAxis dataKey="pilar" tick={{ fill: "#64748b", fontSize: 12, fontWeight: 500 }} />
                        <PolarRadiusAxis angle={30} domain={[0, 10]} tick={{ fill: "#94a3b8", fontSize: 10 }} />
                        <Radar
                          name="Sua Pontuação"
                          dataKey="atual"
                          stroke="hsl(220, 70%, 50%)"
                          fill="hsl(220, 70%, 50%)"
                          fillOpacity={0.25}
                          strokeWidth={2}
                        />
                        <Radar
                          name="Meta da Empresa"
                          dataKey="meta"
                          stroke="hsl(120, 40%, 60%)"
                          fill="hsl(120, 40%, 60%)"
                          fillOpacity={0.1}
                          strokeDasharray="5 5"
                          strokeWidth={2}
                        />
                        <ChartTooltip content={<ChartTooltipContent />} labelStyle={{ color: "#374151" }} />
                        <Legend wrapperStyle={{ paddingTop: "20px" }} />
                      </RadarChart>
                    </ResponsiveContainer>
                  </ChartContainer>
                </div>
              </div>

              {/* Legenda e Contexto */}
              <div className="space-y-4">
                <div>
                  <h4 className="font-semibold text-gray-900 mb-3">Seus Pilares</h4>
                  <div className="space-y-3">
                    {[
                      { name: "Saúde Mental", score: 6.8, weight: "25%", status: "Atenção" },
                      { name: "Saúde Física", score: 7.5, weight: "20%", status: "Bom" },
                      { name: "Sono", score: 6.9, weight: "23%", status: "Bom" },
                      { name: "Nutrição", score: 7.0, weight: "15%", status: "Bom" },
                      { name: "Estresse", score: 6.5, weight: "10%", status: "Atenção" },
                      { name: "Produtividade", score: 7.8, weight: "7%", status: "Muito Bom" },
                    ].map((pilar, index) => (
                      <div key={index} className="flex items-center justify-between text-sm">
                        <div className="flex items-center space-x-2">
                          <div
                            className={`w-3 h-3 rounded-full ${
                              pilar.status === "Muito Bom"
                                ? "bg-green-500"
                                : pilar.status === "Bom"
                                  ? "bg-blue-500"
                                  : "bg-yellow-500"
                            }`}
                          />
                          <span className="font-medium text-gray-700">{pilar.name}</span>
                          <span className="text-gray-400">({pilar.weight})</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <span className="font-semibold text-gray-900">{pilar.score}</span>
                          <Badge
                            variant={
                              pilar.status === "Muito Bom"
                                ? "default"
                                : pilar.status === "Bom"
                                  ? "secondary"
                                  : "outline"
                            }
                            className="text-xs"
                          >
                            {pilar.status}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="pt-4 border-t border-gray-200">
                  <h4 className="font-semibold text-gray-900 mb-2">Como Interpretar</h4>
                  <div className="space-y-2 text-xs text-gray-600">
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 rounded-full bg-green-500" />
                      <span>8.0+ = Muito Bom</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 rounded-full bg-blue-500" />
                      <span>6.0-7.9 = Bom</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 rounded-full bg-yellow-500" />
                      <span>Abaixo de 6.0 = Atenção</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* ISP Evolution Chart */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center">
              <TrendingUp className="w-5 h-5 mr-2 text-blue-600" />
              Evolução do ISP
            </CardTitle>
            <CardDescription>Acompanhe o progresso do seu Índice de Saúde e Performance</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-end justify-between h-32 bg-gray-50 rounded-lg p-4">
                {[
                  { month: "Jan", score: 6.2, color: "bg-red-400" },
                  { month: "Fev", score: 6.5, color: "bg-yellow-400" },
                  { month: "Mar", score: 6.8, color: "bg-yellow-400" },
                  { month: "Abr", score: 7.0, color: "bg-green-400" },
                  { month: "Mai", score: 7.2, color: "bg-green-500" },
                ].map((data, index) => (
                  <div key={index} className="flex flex-col items-center space-y-2">
                    <div className="text-xs font-medium text-gray-600">{data.score}</div>
                    <div
                      className={`w-8 ${data.color} rounded-t-md transition-all hover:opacity-80`}
                      style={{ height: `${(data.score / 10) * 80}px` }}
                    ></div>
                    <div className="text-xs text-gray-500">{data.month}</div>
                  </div>
                ))}
              </div>
              <div className="grid grid-cols-3 gap-4 text-center">
                <div className="p-3 bg-green-50 rounded-lg">
                  <div className="text-lg font-bold text-green-600">+16.1%</div>
                  <div className="text-xs text-gray-600">Crescimento em 5 meses</div>
                </div>
                <div className="text-center p-3 bg-blue-50 rounded-lg">
                  <div className="text-lg font-bold text-blue-600">+0.2</div>
                  <div className="text-xs text-gray-600">Melhoria média mensal</div>
                </div>
                <div className="text-center p-3 bg-purple-50 rounded-lg">
                  <div className="text-lg font-bold text-purple-600">8.5</div>
                  <div className="text-xs text-gray-600">Meta para dezembro</div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Action Items and Training Progress */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Próximas Ações */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Target className="w-5 h-5 mr-2 text-blue-600" />
                Próximas Ações Recomendadas
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-start space-x-3 p-3 bg-red-50 rounded-lg border-l-4 border-red-400">
                <div className="w-2 h-2 bg-red-400 rounded-full mt-2"></div>
                <div>
                  <h4 className="font-medium text-red-900">Workshop de Gestão de Estresse</h4>
                  <p className="text-sm text-red-700">Urgente - Score baixo detectado</p>
                  <Link href="/plano-acao">
                    <Button size="sm" className="mt-2 bg-red-600 hover:bg-red-700">
                      Ver Plano Completo
                    </Button>
                  </Link>
                </div>
              </div>

              <div className="flex items-start space-x-3 p-3 bg-yellow-50 rounded-lg border-l-4 border-yellow-400">
                <div className="w-2 h-2 bg-yellow-400 rounded-full mt-2"></div>
                <div>
                  <h4 className="font-medium text-yellow-900">Programa de Exercícios</h4>
                  <p className="text-sm text-yellow-700">Implementar em 30 dias</p>
                  <Link href="/treinamentos">
                    <Button size="sm" variant="outline" className="mt-2">
                      Ver Treinamentos
                    </Button>
                  </Link>
                </div>
              </div>

              <div className="flex items-start space-x-3 p-3 bg-blue-50 rounded-lg border-l-4 border-blue-400">
                <div className="w-2 h-2 bg-blue-400 rounded-full mt-2"></div>
                <div>
                  <h4 className="font-medium text-blue-900">Avaliação Trimestral</h4>
                  <p className="text-sm text-blue-700">Próxima em 15 dias</p>
                  <Link href="/isp">
                    <Button size="sm" variant="outline" className="mt-2">
                      Preparar Avaliação
                    </Button>
                  </Link>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Training Progress */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <BookOpen className="w-5 h-5 mr-2 text-green-600" />
                Treinamentos Recentes
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {recentTrainings.map((training, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    {training.completed ? (
                      <CheckCircle className="w-5 h-5 text-green-600" />
                    ) : (
                      <Play className="w-5 h-5 text-blue-600" />
                    )}
                    <div>
                      <h4 className="font-medium text-gray-900">{training.title}</h4>
                      <div className="flex items-center space-x-2 text-sm text-gray-600">
                        <Clock className="w-3 h-3" />
                        <span>{training.duration}</span>
                        <Badge variant="outline" className="text-xs">
                          {training.type}
                        </Badge>
                      </div>
                    </div>
                  </div>
                  <Link href="/treinamentos">
                    <Button size="sm" variant={training.completed ? "outline" : "default"}>
                      {training.completed ? "Revisar" : "Continuar"}
                    </Button>
                  </Link>
                </div>
              ))}

              <Link href="/treinamentos">
                <Button className="w-full mt-4">Ver Todos os Treinamentos</Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
