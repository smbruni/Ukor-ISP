"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import Link from "next/link"
import { Brain, Heart, Apple, Moon, TrendingUp, Shield, ArrowLeft, CheckCircle, AlertCircle, User } from "lucide-react"

export default function ISPPage() {
  const [currentStep, setCurrentStep] = useState(0)
  const [answers, setAnswers] = useState<Record<string, any>>({})
  const [isCompleted, setIsCompleted] = useState(false)

  // Pesos dos pilares conforme documento
  const pillarWeights = {
    saudeMental: 0.25,
    saudeFisica: 0.2,
    sono: 0.23,
    nutricao: 0.15,
    gestaoEstresse: 0.1,
    produtividade: 0.07,
  }

  const steps = [
    {
      id: "dados-pessoais",
      title: "Dados Pessoais",
      description: "Informações básicas para personalizar sua experiência",
      icon: User,
      color: "blue",
    },
    {
      id: "saude-mental",
      title: "Saúde Mental",
      description: "Avaliação do seu bem-estar emocional e mental",
      icon: Brain,
      color: "purple",
      weight: "25%",
      questions: [
        {
          id: "sm_1",
          question: "Como você avalia seu estado atual de saúde mental?",
          options: [
            { value: 5, label: "Muito bom - Sinto-me mentalmente saudável e equilibrado" },
            {
              value: 4,
              label: "Bom - Minha saúde mental é geralmente positiva, mas enfrento alguns desafios ocasionais",
            },
            {
              value: 3,
              label: "Regular - Tenho altos e baixos na minha saúde mental e gostaria de melhorar alguns aspectos",
            },
            { value: 2, label: "Ruim - Estou enfrentando dificuldades significativas em relação à minha saúde mental" },
            { value: 1, label: "Muito ruim - Minha saúde mental está comprometida e preciso de apoio urgente" },
          ],
        },
        {
          id: "sm_2",
          question: "Como você avalia seu nível atual de ansiedade?",
          options: [
            { value: 5, label: "Estou bem, minha ansiedade está sob controle" },
            { value: 3, label: "Está um pouco acima do normal, mas ainda é gerenciável" },
            { value: 1, label: "Minha ansiedade é alta, afetando minha saúde e/ou desempenho no trabalho" },
          ],
        },
        {
          id: "sm_3",
          question:
            "Você já foi diagnosticado com algum transtorno mental? (depressão, transtorno de ansiedade generalizada, bipolaridade, TDAH, transtorno obsessivo-compulsivo, estresse pós-traumático, etc.)",
          options: [
            { value: 2, label: "Sim" },
            { value: 5, label: "Não" },
          ],
        },
        {
          id: "sm_4",
          question: "Você tem perdido interesse pelas coisas?",
          options: [
            { value: 1, label: "Sim" },
            { value: 5, label: "Não" },
          ],
        },
        {
          id: "sm_5",
          question: "Você tem se sentido uma pessoa inútil?",
          options: [
            { value: 1, label: "Sim" },
            { value: 5, label: "Não" },
          ],
        },
        {
          id: "sm_6",
          question: "Sente-se cansado a maior parte do tempo?",
          options: [
            { value: 1, label: "Sim" },
            { value: 5, label: "Não" },
          ],
        },
      ],
    },
    {
      id: "saude-fisica",
      title: "Saúde Física",
      description: "Avaliação da sua condição física e hábitos de saúde",
      icon: Heart,
      color: "red",
      weight: "20%",
      questions: [
        {
          id: "sf_1",
          question: "Como você avalia seu estado atual de saúde física?",
          options: [
            { value: 5, label: "Muito bom - Sinto-me saudável e com energia" },
            { value: 4, label: "Bom - Estou razoavelmente saudável, mas poderia melhorar em alguns aspectos" },
            { value: 3, label: "Regular - Tenho algumas preocupações com minha saúde física" },
            { value: 2, label: "Ruim - Estou enfrentando desafios significativos em relação à minha saúde física" },
            { value: 1, label: "Muito ruim - Minha saúde física está comprometida e preciso de cuidados urgentes" },
          ],
        },
        {
          id: "sf_2",
          question: "Com que frequência você faz atividade física?",
          options: [
            { value: 5, label: "Mais de 5 vezes por semana" },
            { value: 4, label: "4 ou 5 vezes por semana" },
            { value: 3, label: "3 vezes por semana" },
            { value: 2, label: "Menos de 2 vezes por semana" },
            { value: 1, label: "Não faço" },
          ],
        },
        {
          id: "sf_3",
          question: "Você tem algum problema de saúde física que afete sua qualidade de vida?",
          options: [
            { value: 2, label: "Sim" },
            { value: 5, label: "Não" },
          ],
        },
        {
          id: "sf_4",
          question: "Você consome álcool?",
          options: [
            { value: 1, label: "Mais de 5 vezes por semana" },
            { value: 2, label: "4 ou 5 vezes por semana" },
            { value: 3, label: "3 vezes por semana" },
            { value: 4, label: "Menos de 2 vezes por semana" },
            { value: 5, label: "Não consumo" },
          ],
        },
        {
          id: "sf_5",
          question: "Com que frequência você faz check-ups médicos de rotina?",
          options: [
            { value: 5, label: "Anualmente" },
            { value: 3, label: "A cada 2 ou 3 anos" },
            { value: 1, label: "Não faço a mais de 2 anos" },
          ],
        },
        {
          id: "sf_6",
          question: "Você fuma?",
          options: [
            { value: 1, label: "Sim" },
            { value: 5, label: "Não" },
          ],
        },
      ],
    },
    {
      id: "sono",
      title: "Sono",
      description: "Avaliação da qualidade e padrões do seu sono",
      icon: Moon,
      color: "blue",
      weight: "23%",
      questions: [
        {
          id: "sono_1",
          question: "O quão satisfeito(a) você está com seu sono hoje?",
          options: [
            { value: 5, label: "Satisfeito" },
            { value: 4, label: "Pouco satisfeito" },
            { value: 3, label: "Nem satisfeito, nem insatisfeito" },
            { value: 2, label: "Pouco insatisfeito" },
            { value: 1, label: "Insatisfeito" },
          ],
        },
        {
          id: "sono_2",
          question: "Você experimenta dificuldade para dormir por preocupações com o trabalho?",
          options: [
            { value: 1, label: "Sim" },
            { value: 5, label: "Não" },
          ],
        },
        {
          id: "sono_3",
          question: "Você dorme tranquilamente todas as noites?",
          options: [
            { value: 5, label: "Sim" },
            { value: 1, label: "Não" },
          ],
        },
        {
          id: "sono_4",
          question: "Quantas horas de sono você dorme em média por noite?",
          options: [
            { value: 5, label: "7 - 9 horas" },
            { value: 3, label: "Cerca de 6h" },
            { value: 1, label: "Menos de 6 horas ou mais de 9 horas" },
          ],
        },
        {
          id: "sono_5",
          question: "Você bebe mais de 3 xícaras de café por dia?",
          options: [
            { value: 2, label: "Sim" },
            { value: 5, label: "Não" },
          ],
        },
        {
          id: "sono_6",
          question: "Você toma algum remédio ou suplemento para dormir?",
          options: [
            { value: 1, label: "Sim, tomo remédio controlado" },
            { value: 3, label: "Sim, tomo suplemento (ex. melatonina)" },
            { value: 5, label: "Não" },
          ],
        },
      ],
    },
    {
      id: "nutricao",
      title: "Nutrição",
      description: "Avaliação dos seus hábitos alimentares e nutricionais",
      icon: Apple,
      color: "green",
      weight: "15%",
      questions: [
        {
          id: "nut_1",
          question: "Como você avalia sua alimentação e hábitos nutricionais, atualmente?",
          options: [
            {
              value: 5,
              label: "Muito boa - Tenho uma alimentação balanceada e variada, com foco na qualidade dos alimentos",
            },
            {
              value: 4,
              label: "Boa - Geralmente faço escolhas saudáveis, mas posso melhorar alguns aspectos da minha dieta",
            },
            { value: 3, label: "Regular - Minha alimentação é inconsistente e poderia ser mais saudável" },
            {
              value: 2,
              label: "Ruim - Tenho hábitos alimentares pouco saudáveis e preciso de orientação para melhorar",
            },
            {
              value: 1,
              label: "Muito ruim - Minha alimentação é muito prejudicial à minha saúde e requer mudanças urgentes",
            },
          ],
        },
        {
          id: "nut_2",
          question: "Você considera que bebe uma quantidade adequada de água por dia? (mínimo 2 litros)",
          options: [
            { value: 5, label: "Sim" },
            { value: 2, label: "Não" },
          ],
        },
        {
          id: "nut_3",
          question:
            "Com qual frequência você come alimentos ultraprocessados? (Ex.: Macarrão instantâneo, refrigerante, cereal açucarado, etc.)",
          options: [
            { value: 1, label: "Mais de 5 vezes por semana" },
            { value: 3, label: "3 a 5 vezes por semana" },
            { value: 5, label: "Menos de 2 vezes por semana" },
          ],
        },
        {
          id: "nut_4",
          question: "Com qual frequência você come vegetais?",
          options: [
            { value: 5, label: "Mais de 5 vezes por semana" },
            { value: 3, label: "3 a 5 vezes por semana" },
            { value: 1, label: "Menos de 2 vezes por semana" },
          ],
        },
        {
          id: "nut_5",
          question: "Com qual frequência você come frutas?",
          options: [
            { value: 5, label: "Mais de 5 vezes por semana" },
            { value: 3, label: "3 a 5 vezes por semana" },
            { value: 1, label: "Menos de 2 vezes por semana" },
          ],
        },
        {
          id: "nut_6",
          question: "Como você se sente em relação ao seu peso atual?",
          options: [
            { value: 1, label: "Abaixo do meu peso ideal" },
            { value: 5, label: "Perto do meu peso ideal" },
            { value: 1, label: "Acima do meu peso ideal" },
          ],
        },
      ],
    },
    {
      id: "gestao-estresse",
      title: "Gestão de Estresse",
      description: "Avaliação do seu nível e gestão do estresse",
      icon: Shield,
      color: "indigo",
      weight: "10%",
      questions: [
        {
          id: "ge_1",
          question: "Como você avalia seu nível atual de estresse?",
          options: [
            {
              value: 5,
              label:
                "Bom - Meu nível de estresse está baixo e gerenciável, não afetando significativamente minha saúde ou desempenho no trabalho",
            },
            {
              value: 4,
              label:
                "Gerenciável - Meu estresse está presente, mas consigo administrá-lo de forma eficaz, sem grandes impactos",
            },
            {
              value: 3,
              label:
                "Maior que o normal - Sinto um aumento no estresse em comparação com minha média, mas ainda consigo gerenciar bem a situação",
            },
            { value: 1, label: "Muito estressado e isso tem afetado minha saúde e desempenho no trabalho" },
          ],
        },
        {
          id: "ge_2",
          question: "Em uma escala de 1 a 5, qual foi o seu nível médio de estresse diário nas últimas 2 semanas?",
          options: [
            { value: 5, label: "1 - Meu nível de estresse foi mínimo; estive calmo e tranquilo na maioria dos dias" },
            {
              value: 4,
              label: "2 - Senti um pouco de estresse ocasionalmente, mas consegui lidar bem com as situações",
            },
            {
              value: 3,
              label:
                "3 - Experimentei um nível moderado de estresse em alguns dias, o que afetou um pouco meu bem-estar",
            },
            {
              value: 2,
              label:
                "4 - Meu estresse foi significativo em vários dias, impactando minha capacidade de lidar com as responsabilidades",
            },
            {
              value: 1,
              label:
                "5 - Estive sob um nível muito alto de estresse constantemente nas últimas duas semanas, afetando negativamente minha saúde e desempenho",
            },
          ],
        },
        {
          id: "ge_3",
          question: 'Com que frequência você sente que teve um dia que classifica como "ruim" ou "estressante"?',
          options: [
            { value: 1, label: "Todos os dias" },
            { value: 2, label: "4 ou 5 vezes por semana" },
            { value: 3, label: "3 vezes por semana" },
            { value: 4, label: "Menos de 2 vezes por semana" },
            { value: 5, label: "Não tenho estresse no trabalho" },
          ],
        },
        {
          id: "ge_4",
          question: "Qual porcentagem do seu estresse geral você diria que está relacionada ao trabalho?",
          options: [
            { value: 1, label: "De 75 a 100%" },
            { value: 3, label: "De 35 a 74%" },
            { value: 5, label: "De 0 a 34%" },
          ],
        },
        {
          id: "ge_5",
          question:
            "Você já precisou abandonar um dia de trabalho no meio ou faltar no trabalho por estar demasiadamente estressado?",
          options: [
            { value: 1, label: "Sim" },
            { value: 5, label: "Não" },
          ],
        },
      ],
    },
    {
      id: "produtividade",
      title: "Produtividade",
      description: "Avaliação da sua eficiência e foco no trabalho",
      icon: TrendingUp,
      color: "orange",
      weight: "7%",
      questions: [
        {
          id: "prod_1",
          question: "Como você avalia seu nível de produtividade atualmente?",
          options: [
            { value: 5, label: "Muito bom - Estou altamente produtivo e eficiente em todas as minhas tarefas" },
            {
              value: 4,
              label: "Bom - Tenho um bom nível de produtividade, mas ainda posso melhorar em alguns aspectos",
            },
            {
              value: 3,
              label: "Regular - Às vezes, sinto que minha produtividade poderia ser melhorada com algumas mudanças",
            },
            {
              value: 2,
              label: "Ruim - Estou enfrentando desafios significativos em relação à minha produtividade e eficiência",
            },
            { value: 1, label: "Muito ruim - Minha produtividade está comprometida e preciso melhorar" },
          ],
        },
        {
          id: "prod_2",
          question:
            "Em uma escala de 1 a 5, quão difícil é para você se concentrar e permanecer focado(a) ao longo do dia de trabalho?",
          options: [
            {
              value: 5,
              label: "1 - Não tenho dificuldade em me concentrar; consigo manter o foco facilmente durante todo o dia",
            },
            {
              value: 4,
              label: "2 - Às vezes, tenho dificuldade em manter o foco, mas geralmente consigo retomar rapidamente",
            },
            {
              value: 3,
              label:
                "3 - Tenho algumas dificuldades em me concentrar, o que pode afetar minha produtividade em certos momentos",
            },
            {
              value: 2,
              label:
                "4 - É bastante difícil para mim me concentrar ao longo do dia; isso impacta significativamente minha eficiência",
            },
            {
              value: 1,
              label:
                "5 - Tenho extrema dificuldade em me concentrar; isso interfere drasticamente na minha capacidade de realizar meu trabalho de forma eficaz",
            },
          ],
        },
        {
          id: "prod_3",
          question: "Você sente dificuldade para tomar decisões?",
          options: [
            { value: 1, label: "Sim" },
            { value: 5, label: "Não" },
          ],
        },
      ],
    },
  ]

  const handleAnswer = (questionId: string, value: any) => {
    setAnswers({ ...answers, [questionId]: value })
  }

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1)
    } else {
      setIsCompleted(true)
    }
  }

  const handlePrevious = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1)
    }
  }

  const calculateISP = () => {
    const pillarScores = {
      saudeMental: 0,
      saudeFisica: 0,
      sono: 0,
      nutricao: 0,
      gestaoEstresse: 0,
      produtividade: 0,
    }

    // Calcular score de cada pilar
    steps.forEach((step) => {
      if (step.questions) {
        const stepAnswers = step.questions.map((q) => answers[q.id] || 0)
        const stepAverage = stepAnswers.reduce((sum, val) => sum + val, 0) / stepAnswers.length
        const stepPercentage = (stepAverage / 5) * 100

        switch (step.id) {
          case "saude-mental":
            pillarScores.saudeMental = stepPercentage
            break
          case "saude-fisica":
            pillarScores.saudeFisica = stepPercentage
            break
          case "sono":
            pillarScores.sono = stepPercentage
            break
          case "nutricao":
            pillarScores.nutricao = stepPercentage
            break
          case "gestao-estresse":
            pillarScores.gestaoEstresse = stepPercentage
            break
          case "produtividade":
            pillarScores.produtividade = stepPercentage
            break
        }
      }
    })

    // Calcular ISP ponderado
    const weightedScore =
      pillarScores.saudeMental * pillarWeights.saudeMental +
      pillarScores.saudeFisica * pillarWeights.saudeFisica +
      pillarScores.sono * pillarWeights.sono +
      pillarScores.nutricao * pillarWeights.nutricao +
      pillarScores.gestaoEstresse * pillarWeights.gestaoEstresse +
      pillarScores.produtividade * pillarWeights.produtividade

    return {
      isp: (weightedScore / 10).toFixed(1),
      pillarScores,
    }
  }

  const getScoreMessage = (score: number, pillar: string) => {
    const messages = {
      "saude-mental": {
        ruim: "Sua saúde mental precisa de atenção imediata. Considere buscar ajuda profissional e pratique técnicas de autocuidado sempre que possível.",
        regular: "Há espaço para melhorias. Reserve um tempo para atividades que te fazem bem.",
        bom: "Continue assim! Mantenha suas práticas atuais e considere fazer do seu desenvolvimento pessoal uma prática contínua.",
      },
      "saude-fisica": {
        ruim: "Sua saúde física requer atenção. Experimente começar com caminhadas curtas diárias e aumente gradualmente.",
        regular: "Você está no caminho certo. Tente adicionar exercícios de força duas vezes por semana.",
        bom: "Excelente! Desafie-se com novos tipos de exercícios para manter o progresso.",
      },
      sono: {
        ruim: "Seu sono precisa de melhorias urgentes. A má qualidade do sono afeta todos os outros pilares de Saúde e Performance.",
        regular:
          "Seu sono pode melhorar. Considere ter uma prática de relaxamento como um banho morno ou exercício de respiração.",
        bom: "Você tem bons hábitos de sono. Continue priorizando seu descanso e ajuste conforme necessário.",
      },
      nutricao: {
        ruim: "Sua nutrição precisa de atenção. Comece reduzindo alimentos processados e optando por alternativas mais naturais.",
        regular:
          "Sua dieta está no caminho certo. Experimente variar suas receitas, incluindo porções adequadas de legumes.",
        bom: "Excelente! Continue explorando opções nutritivas e equilibradas em sua dieta.",
      },
      "gestao-estresse": {
        ruim: "O estresse está afetando sua vida. Comece identificando suas principais fontes de estresse e crie um plano de ação.",
        regular:
          "Você está lidando com o estresse, mas pode melhorar. Experimente dizer 'não' para compromissos não essenciais.",
        bom: "Você gerencia bem o estresse. Manter um equilíbrio saudável entre trabalho e vida pessoal é um desafio.",
      },
      produtividade: {
        ruim: "Sua produtividade precisa de atenção. Comece organizando seu espaço de trabalho e eliminando distrações.",
        regular:
          "Você está no caminho certo. Para otimizar sua eficiência, identifique seus períodos de maior produtividade.",
        bom: "Excelente! Considere ser um orientador de produtividade na sua equipe, compartilhando suas técnicas.",
      },
    }

    const category = score <= 33 ? "ruim" : score <= 66 ? "regular" : "bom"
    return messages[pillar]?.[category] || ""
  }

  const currentStepData = steps[currentStep]
  const Icon = currentStepData?.icon

  // Verificar se todas as perguntas do step atual foram respondidas
  const isStepComplete = () => {
    if (currentStepData.id === "dados-pessoais") {
      return answers.nome && answers.email && answers.empresa && answers.setor && answers.genero && answers.idade
    }
    if (currentStepData.questions) {
      return currentStepData.questions.every((q) => answers[q.id] !== undefined)
    }
    return true
  }

  if (isCompleted) {
    const result = calculateISP()
    return (
      <div className="min-h-screen bg-gray-50">
        <header className="bg-white border-b border-gray-200 px-6 py-4">
          <div className="flex items-center space-x-4">
            <Link href="/">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Voltar ao Dashboard
              </Button>
            </Link>
            <h1 className="text-xl font-semibold text-gray-900">Avaliação ISP Concluída</h1>
          </div>
        </header>

        <div className="p-6 max-w-6xl mx-auto">
          <Card className="mb-6 bg-gradient-to-r from-green-50 to-blue-50">
            <CardHeader className="text-center">
              <CheckCircle className="w-16 h-16 text-green-600 mx-auto mb-4" />
              <CardTitle className="text-2xl">Parabéns! Avaliação Concluída</CardTitle>
              <CardDescription>
                Seu ISP foi calculado com base nas suas respostas usando os pesos oficiais
              </CardDescription>
            </CardHeader>
            <CardContent className="text-center space-y-6">
              <div className="flex justify-center">
                <div className="w-32 h-32 rounded-full bg-green-100 flex items-center justify-center">
                  <span className="text-4xl font-bold text-green-600">{result.isp}</span>
                </div>
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-2">Seu Índice de Saúde e Performance</h3>
                <Progress value={Number(result.isp) * 10} className="h-3 mb-4" />
              </div>
            </CardContent>
          </Card>

          {/* Detalhamento por Pilares */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
            {Object.entries(result.pillarScores).map(([pillar, score], index) => {
              const pillarNames = {
                saudeMental: "Saúde Mental",
                saudeFisica: "Saúde Física",
                sono: "Sono",
                nutricao: "Nutrição",
                gestaoEstresse: "Gestão de Estresse",
                produtividade: "Produtividade",
              }
              const pillarIds = {
                saudeMental: "saude-mental",
                saudeFisica: "saude-fisica",
                sono: "sono",
                nutricao: "nutricao",
                gestaoEstresse: "gestao-estresse",
                produtividade: "produtividade",
              }
              const weights = {
                saudeMental: "25%",
                saudeFisica: "20%",
                sono: "23%",
                nutricao: "15%",
                gestaoEstresse: "10%",
                produtividade: "7%",
              }

              return (
                <Card key={index} className="hover:shadow-md transition-shadow">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-sm font-medium">{pillarNames[pillar]}</CardTitle>
                      <Badge variant="outline">{weights[pillar]}</Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="text-center mb-3">
                      <div className="text-2xl font-bold text-blue-600">{score.toFixed(1)}%</div>
                      <Progress value={score} className="h-2 mt-2" />
                    </div>
                    <p className="text-xs text-gray-600">{getScoreMessage(score, pillarIds[pillar])}</p>
                  </CardContent>
                </Card>
              )
            })}
          </div>

          <div className="flex gap-4 justify-center">
            <Link href="/plano-acao">
              <Button>Ver Plano de Ação Personalizado</Button>
            </Link>
            <Link href="/treinamentos">
              <Button variant="outline">Explorar Treinamentos</Button>
            </Link>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Link href="/">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Voltar
              </Button>
            </Link>
            <h1 className="text-xl font-semibold text-gray-900">Avaliação ISP - Índice de Saúde e Performance</h1>
          </div>
          <Badge variant="outline">
            {currentStep + 1} de {steps.length}
          </Badge>
        </div>
      </header>

      <div className="p-6 max-w-4xl mx-auto">
        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex justify-between text-sm text-gray-600 mb-2">
            <span>Progresso da Avaliação</span>
            <span>{Math.round(((currentStep + 1) / steps.length) * 100)}%</span>
          </div>
          <Progress value={((currentStep + 1) / steps.length) * 100} className="h-2" />
        </div>

        {/* Step Navigation */}
        <div className="flex justify-center mb-8">
          <div className="flex space-x-2 overflow-x-auto">
            {steps.map((step, index) => {
              const StepIcon = step.icon
              return (
                <div
                  key={index}
                  className={`flex items-center space-x-2 px-3 py-2 rounded-lg text-sm ${
                    index === currentStep
                      ? "bg-blue-100 text-blue-700"
                      : index < currentStep
                        ? "bg-green-100 text-green-700"
                        : "bg-gray-100 text-gray-500"
                  }`}
                >
                  <StepIcon className="w-4 h-4" />
                  <span className="whitespace-nowrap">{step.title}</span>
                  {step.weight && (
                    <Badge variant="outline" className="text-xs">
                      {step.weight}
                    </Badge>
                  )}
                </div>
              )
            })}
          </div>
        </div>

        {/* Question Card */}
        <Card className="mb-6">
          <CardHeader>
            <div className="flex items-center space-x-3 mb-4">
              <div className={`w-12 h-12 rounded-lg bg-${currentStepData.color}-500 flex items-center justify-center`}>
                <Icon className="w-6 h-6 text-white" />
              </div>
              <div>
                <CardTitle className="text-lg">{currentStepData.title}</CardTitle>
                <CardDescription>{currentStepData.description}</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {currentStepData.id === "dados-pessoais" ? (
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="nome">Nome completo *</Label>
                    <Input
                      id="nome"
                      value={answers.nome || ""}
                      onChange={(e) => handleAnswer("nome", e.target.value)}
                      placeholder="Seu nome completo"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">E-mail *</Label>
                    <Input
                      id="email"
                      type="email"
                      value={answers.email || ""}
                      onChange={(e) => handleAnswer("email", e.target.value)}
                      placeholder="seu@email.com"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="empresa">Empresa *</Label>
                    <Input
                      id="empresa"
                      value={answers.empresa || ""}
                      onChange={(e) => handleAnswer("empresa", e.target.value)}
                      placeholder="Nome da empresa"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="setor">Setor ou área *</Label>
                    <Input
                      id="setor"
                      value={answers.setor || ""}
                      onChange={(e) => handleAnswer("setor", e.target.value)}
                      placeholder="Ex: Tecnologia, RH, Vendas"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label>Gênero *</Label>
                    <Select value={answers.genero || ""} onValueChange={(value) => handleAnswer("genero", value)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="masculino">Masculino</SelectItem>
                        <SelectItem value="feminino">Feminino</SelectItem>
                        <SelectItem value="transgenero">Transgênero</SelectItem>
                        <SelectItem value="nao-binario">Não-binário</SelectItem>
                        <SelectItem value="outros">Outros</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Idade *</Label>
                    <Select value={answers.idade || ""} onValueChange={(value) => handleAnswer("idade", value)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="menos-18">Menos de 18</SelectItem>
                        <SelectItem value="18-30">18 a 30</SelectItem>
                        <SelectItem value="31-45">31 a 45</SelectItem>
                        <SelectItem value="46-55">46 a 55</SelectItem>
                        <SelectItem value="56-77">56 a 77</SelectItem>
                        <SelectItem value="77-mais">77 ou mais</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Raça ou cor</Label>
                    <Select value={answers.raca || ""} onValueChange={(value) => handleAnswer("raca", value)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="branca">Branca</SelectItem>
                        <SelectItem value="preta">Preta</SelectItem>
                        <SelectItem value="parda">Parda</SelectItem>
                        <SelectItem value="indigena">Indígena</SelectItem>
                        <SelectItem value="amarela">Amarela</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
            ) : (
              currentStepData.questions && (
                <div className="space-y-6">
                  {currentStepData.questions.map((question, qIndex) => (
                    <div key={qIndex} className="space-y-3">
                      <h4 className="font-medium text-gray-900">
                        {qIndex + 1}.{question.id.split("_")[1]} {question.question}
                      </h4>
                      <RadioGroup
                        value={answers[question.id]?.toString() || ""}
                        onValueChange={(value) => handleAnswer(question.id, Number(value))}
                      >
                        {question.options.map((option, oIndex) => (
                          <div key={oIndex} className="flex items-start space-x-2 p-3 rounded-lg hover:bg-gray-50">
                            <RadioGroupItem
                              value={option.value.toString()}
                              id={`${question.id}-${oIndex}`}
                              className="mt-1"
                            />
                            <Label
                              htmlFor={`${question.id}-${oIndex}`}
                              className="flex-1 cursor-pointer leading-relaxed"
                            >
                              {option.label}
                            </Label>
                          </div>
                        ))}
                      </RadioGroup>
                    </div>
                  ))}
                </div>
              )
            )}
          </CardContent>
        </Card>

        {/* Navigation */}
        <div className="flex justify-between">
          <Button variant="outline" onClick={handlePrevious} disabled={currentStep === 0}>
            Anterior
          </Button>
          <Button
            onClick={handleNext}
            disabled={!isStepComplete()}
            className={currentStep === steps.length - 1 ? "bg-green-600 hover:bg-green-700" : ""}
          >
            {currentStep === steps.length - 1 ? "Finalizar Avaliação" : "Próxima"}
          </Button>
        </div>

        {/* Help Text */}
        <div className="mt-6 p-4 bg-blue-50 rounded-lg border-l-4 border-blue-400">
          <div className="flex items-start space-x-3">
            <AlertCircle className="w-5 h-5 text-blue-600 mt-0.5" />
            <div>
              <h4 className="font-medium text-blue-900">Sobre esta avaliação</h4>
              <p className="text-sm text-blue-700">
                Esta avaliação segue o questionário oficial do ISP com pesos específicos para cada pilar: Saúde Mental
                (25%), Sono (23%), Saúde Física (20%), Nutrição (15%), Gestão de Estresse (10%) e Produtividade (7%).
                Responda com honestidade para obter um resultado preciso.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
