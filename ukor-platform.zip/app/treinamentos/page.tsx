"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import Link from "next/link"
import {
  ArrowLeft,
  Search,
  Play,
  Clock,
  Users,
  Star,
  BookOpen,
  Video,
  FileText,
  Headphones,
  CheckCircle,
  Filter,
} from "lucide-react"

export default function TreinamentosPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("todos")

  const categories = [
    { id: "todos", name: "Todos", count: 24 },
    { id: "saude-mental", name: "Saúde Mental", count: 8 },
    { id: "saude-fisica", name: "Saúde Física", count: 6 },
    { id: "nutricao", name: "Nutrição", count: 4 },
    { id: "sono", name: "Sono", count: 3 },
    { id: "produtividade", name: "Produtividade", count: 5 },
    { id: "estresse", name: "Gestão de Estresse", count: 4 },
  ]

  const trainings = [
    {
      id: 1,
      title: "Mindfulness para Redução do Estresse",
      description: "Aprenda técnicas de mindfulness para gerenciar o estresse no ambiente de trabalho",
      category: "saude-mental",
      type: "Curso",
      duration: "2h 30min",
      lessons: 8,
      rating: 4.8,
      students: 1250,
      level: "Iniciante",
      instructor: "Dr. Ana Silva",
      thumbnail: "/placeholder.svg?height=200&width=300",
      completed: false,
      progress: 0,
      tags: ["Mindfulness", "Estresse", "Bem-estar"],
    },
    {
      id: 2,
      title: "Nutrição Funcional no Trabalho",
      description: "Como manter uma alimentação saudável durante a jornada de trabalho",
      category: "nutricao",
      type: "Workshop",
      duration: "1h 45min",
      lessons: 5,
      rating: 4.6,
      students: 890,
      level: "Iniciante",
      instructor: "Nutricionista Carlos Lima",
      thumbnail: "/placeholder.svg?height=200&width=300",
      completed: true,
      progress: 100,
      tags: ["Alimentação", "Saúde", "Energia"],
    },
    {
      id: 3,
      title: "Exercícios de Escritório",
      description: "Exercícios simples para fazer durante o expediente e melhorar sua saúde física",
      category: "saude-fisica",
      type: "Vídeo",
      duration: "45min",
      lessons: 12,
      rating: 4.7,
      students: 2100,
      level: "Todos os níveis",
      instructor: "Personal Trainer Maria Santos",
      thumbnail: "/placeholder.svg?height=200&width=300",
      completed: false,
      progress: 60,
      tags: ["Exercícios", "Postura", "Movimento"],
    },
    {
      id: 4,
      title: "Higiene do Sono para Profissionais",
      description: "Estratégias para melhorar a qualidade do sono e aumentar a produtividade",
      category: "sono",
      type: "Curso",
      duration: "1h 20min",
      lessons: 6,
      rating: 4.9,
      students: 756,
      level: "Iniciante",
      instructor: "Dr. Pedro Oliveira",
      thumbnail: "/placeholder.svg?height=200&width=300",
      completed: false,
      progress: 0,
      tags: ["Sono", "Descanso", "Energia"],
    },
    {
      id: 5,
      title: "Gestão do Tempo e Produtividade",
      description: "Técnicas avançadas para otimizar seu tempo e aumentar sua produtividade",
      category: "produtividade",
      type: "Curso",
      duration: "3h 15min",
      lessons: 10,
      rating: 4.8,
      students: 1890,
      level: "Intermediário",
      instructor: "Coach João Ferreira",
      thumbnail: "/placeholder.svg?height=200&width=300",
      completed: false,
      progress: 25,
      tags: ["Tempo", "Organização", "Eficiência"],
    },
    {
      id: 6,
      title: "Respiração Consciente Anti-Estresse",
      description: "Técnicas de respiração para controlar a ansiedade e o estresse",
      category: "estresse",
      type: "Áudio",
      duration: "30min",
      lessons: 4,
      rating: 4.5,
      students: 650,
      level: "Iniciante",
      instructor: "Terapeuta Laura Costa",
      thumbnail: "/placeholder.svg?height=200&width=300",
      completed: false,
      progress: 0,
      tags: ["Respiração", "Relaxamento", "Ansiedade"],
    },
  ]

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "Curso":
        return BookOpen
      case "Vídeo":
        return Video
      case "Workshop":
        return Users
      case "Áudio":
        return Headphones
      default:
        return FileText
    }
  }

  const filteredTrainings = trainings.filter((training) => {
    const matchesSearch =
      training.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      training.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      training.tags.some((tag) => tag.toLowerCase().includes(searchTerm.toLowerCase()))

    const matchesCategory = selectedCategory === "todos" || training.category === selectedCategory

    return matchesSearch && matchesCategory
  })

  const myTrainings = trainings.filter((t) => t.completed || t.progress > 0)
  const recommendedTrainings = trainings.filter((t) => !t.completed && t.progress === 0).slice(0, 3)

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Link href="/">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Voltar
              </Button>
            </Link>
            <h1 className="text-xl font-semibold text-gray-900">Treinamentos e Cursos</h1>
          </div>
          <Badge variant="outline" className="bg-blue-50 text-blue-700">
            {myTrainings.length} em progresso
          </Badge>
        </div>
      </header>

      <div className="p-6 max-w-7xl mx-auto">
        {/* Search and Filters */}
        <div className="mb-6 space-y-4">
          <div className="flex gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Buscar treinamentos, cursos ou temas..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Button variant="outline">
              <Filter className="w-4 h-4 mr-2" />
              Filtros
            </Button>
          </div>

          {/* Categories */}
          <div className="flex gap-2 overflow-x-auto pb-2">
            {categories.map((category) => (
              <Button
                key={category.id}
                variant={selectedCategory === category.id ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedCategory(category.id)}
                className="whitespace-nowrap"
              >
                {category.name} ({category.count})
              </Button>
            ))}
          </div>
        </div>

        <Tabs defaultValue="todos" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="todos">Todos os Treinamentos</TabsTrigger>
            <TabsTrigger value="meus">Meus Treinamentos</TabsTrigger>
            <TabsTrigger value="recomendados">Recomendados</TabsTrigger>
          </TabsList>

          <TabsContent value="todos" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredTrainings.map((training) => {
                const TypeIcon = getTypeIcon(training.type)
                return (
                  <Card key={training.id} className="hover:shadow-lg transition-shadow">
                    <div className="relative">
                      <img
                        src={training.thumbnail || "/placeholder.svg"}
                        alt={training.title}
                        className="w-full h-48 object-cover rounded-t-lg"
                      />
                      {training.completed && (
                        <div className="absolute top-2 right-2 bg-green-600 text-white p-1 rounded-full">
                          <CheckCircle className="w-4 h-4" />
                        </div>
                      )}
                      {training.progress > 0 && !training.completed && (
                        <div className="absolute bottom-2 left-2 right-2">
                          <Progress value={training.progress} className="h-1" />
                        </div>
                      )}
                    </div>
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between">
                        <Badge variant="outline" className="mb-2">
                          <TypeIcon className="w-3 h-3 mr-1" />
                          {training.type}
                        </Badge>
                        <div className="flex items-center space-x-1">
                          <Star className="w-4 h-4 text-yellow-400 fill-current" />
                          <span className="text-sm text-gray-600">{training.rating}</span>
                        </div>
                      </div>
                      <CardTitle className="text-lg leading-tight">{training.title}</CardTitle>
                      <CardDescription className="text-sm">{training.description}</CardDescription>
                    </CardHeader>
                    <CardContent className="pt-0">
                      <div className="flex items-center justify-between text-sm text-gray-600 mb-3">
                        <div className="flex items-center space-x-3">
                          <div className="flex items-center space-x-1">
                            <Clock className="w-4 h-4" />
                            <span>{training.duration}</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <Users className="w-4 h-4" />
                            <span>{training.students}</span>
                          </div>
                        </div>
                        <Badge variant="secondary" className="text-xs">
                          {training.level}
                        </Badge>
                      </div>
                      <div className="flex gap-1 mb-3">
                        {training.tags.slice(0, 2).map((tag, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                      <Button className="w-full">
                        {training.completed ? (
                          "Revisar"
                        ) : training.progress > 0 ? (
                          "Continuar"
                        ) : (
                          <>
                            <Play className="w-4 h-4 mr-2" />
                            Iniciar
                          </>
                        )}
                      </Button>
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          </TabsContent>

          <TabsContent value="meus" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {myTrainings.map((training) => {
                const TypeIcon = getTypeIcon(training.type)
                return (
                  <Card key={training.id} className="hover:shadow-lg transition-shadow">
                    <div className="relative">
                      <img
                        src={training.thumbnail || "/placeholder.svg"}
                        alt={training.title}
                        className="w-full h-48 object-cover rounded-t-lg"
                      />
                      {training.completed && (
                        <div className="absolute top-2 right-2 bg-green-600 text-white p-1 rounded-full">
                          <CheckCircle className="w-4 h-4" />
                        </div>
                      )}
                    </div>
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between">
                        <Badge variant="outline" className="mb-2">
                          <TypeIcon className="w-3 h-3 mr-1" />
                          {training.type}
                        </Badge>
                        <Badge variant={training.completed ? "default" : "secondary"}>
                          {training.completed ? "Concluído" : `${training.progress}%`}
                        </Badge>
                      </div>
                      <CardTitle className="text-lg leading-tight">{training.title}</CardTitle>
                    </CardHeader>
                    <CardContent className="pt-0">
                      {!training.completed && (
                        <div className="mb-3">
                          <div className="flex justify-between text-sm text-gray-600 mb-1">
                            <span>Progresso</span>
                            <span>{training.progress}%</span>
                          </div>
                          <Progress value={training.progress} className="h-2" />
                        </div>
                      )}
                      <Button className="w-full">
                        {training.completed ? "Revisar Conteúdo" : "Continuar Treinamento"}
                      </Button>
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          </TabsContent>

          <TabsContent value="recomendados" className="space-y-4">
            <Card className="mb-6 bg-gradient-to-r from-blue-50 to-purple-50">
              <CardHeader>
                <CardTitle>Recomendações Personalizadas</CardTitle>
                <CardDescription>
                  Baseado no seu ISP atual, recomendamos estes treinamentos para melhorar sua saúde e performance
                </CardDescription>
              </CardHeader>
            </Card>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {recommendedTrainings.map((training) => {
                const TypeIcon = getTypeIcon(training.type)
                return (
                  <Card key={training.id} className="hover:shadow-lg transition-shadow border-blue-200">
                    <div className="relative">
                      <img
                        src={training.thumbnail || "/placeholder.svg"}
                        alt={training.title}
                        className="w-full h-48 object-cover rounded-t-lg"
                      />
                      <div className="absolute top-2 left-2 bg-blue-600 text-white px-2 py-1 rounded text-xs font-medium">
                        Recomendado
                      </div>
                    </div>
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between">
                        <Badge variant="outline" className="mb-2">
                          <TypeIcon className="w-3 h-3 mr-1" />
                          {training.type}
                        </Badge>
                        <div className="flex items-center space-x-1">
                          <Star className="w-4 h-4 text-yellow-400 fill-current" />
                          <span className="text-sm text-gray-600">{training.rating}</span>
                        </div>
                      </div>
                      <CardTitle className="text-lg leading-tight">{training.title}</CardTitle>
                      <CardDescription className="text-sm">{training.description}</CardDescription>
                    </CardHeader>
                    <CardContent className="pt-0">
                      <div className="flex items-center justify-between text-sm text-gray-600 mb-3">
                        <div className="flex items-center space-x-1">
                          <Clock className="w-4 h-4" />
                          <span>{training.duration}</span>
                        </div>
                        <Badge variant="secondary" className="text-xs">
                          {training.level}
                        </Badge>
                      </div>
                      <Button className="w-full bg-blue-600 hover:bg-blue-700">
                        <Play className="w-4 h-4 mr-2" />
                        Começar Agora
                      </Button>
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
